package com.example.atividade1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity<bu> extends AppCompatActivity {

    @Override
    protected <button> void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button b1 = (Button) findViewById(R.id.bt_calcular);

        
        }
    }

    


}
